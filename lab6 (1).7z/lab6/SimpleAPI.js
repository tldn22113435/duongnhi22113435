//import thu vien
var express = require('express');
var bodyParser = require("body-parser");
var cors = require('cors');
var mysql = require('mysql2'); //npm install mysql
var app = express();


app.use(cors());
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }))

//du lieu json
news = [{ "id": 1, "title": "Không khí lạnh mạnh tràn về, miền Bắc có nơi rét dưới 14 độ C", "linhvuc": "Xã hội", "content": "Không khí lạnh tràn về khiến khu vực Bắc Bộ và Bắc Trung Bộ đêm và sáng trời lạnh, vùng núi phía Bắc có nơi trời rét. ...", "img": "1.jpg", "time": "42 phút trước" },
{ "id": 2, "title": "Bắt giữ thiếu niên 14 tuổi bỏ thuốc độc vào sữa làm cha và bà nội tử vong", "linhvuc": "Xã hội", "content": "Theo thông tin ban đầu, nghi phạm đã khai nhận từ khi lên 6 tuổi, do cha mẹ ly thân nên bỏ học và cùng mẹ làm ở vựa ...", "img": "2.jpg", "time": "1 giờ trước" },
]

//ket noi voi csdl
var con = mysql.createConnection({
    host: "localhost",
    port: "3306",
    user: "root",
    password: "123456",
    insecureAuth: true,
    database: "kenh14"
});
// in workbench
//ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'your_password';
con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!!!")
    var sql = "SELECT * FROM kenh14.news";
    con.query(sql, function (err, results) {
        if (err) throw err;
        console.log(results);
    })
});



//viet API
app.get("/kenh14", function (req, res) {
    //res.send(news);
    var sql = "SELECT * FROM news";
    con.query(sql, function (err, results) {
        if (err) throw err;
        res.send(results);
    });

})

app.post('/postkenh14', function (req, res) {
    //số lượng các cột trong bảng 
    const { id, title, linhvuc, content, img, time } = req.body
    //sample { id: 4, deviceName: 'DHT22' }
    var sql = "insert into news(id, title, linhvuc, content, img, `time`) value (" + id + ", '" + title + "', '" + linhvuc + "', '" + content + "','" + img + "', '" + time + "')";
    con.query(sql, function (err, results) {
        if (err) throw err;
        res.send('Add successfull');
    });
})

app.get('/kenh14/:linhvuc', function (req, res) {
    const { linhvuc } = req.params
    var sql = "select * from news where linhvuc like '%" + linhvuc + "%'"
    console.log(sql)
    con.query(sql, function (err, results) {
        if (err) throw err;
        res.send(results);
    });
})

app.put('/kenh14', function (req, res) {
    const { id, title } = req.body
    var sql = "update news set title = '"+title+"' where id = '"+id+"';"
    console.log(sql)
    con.query(sql, function (err, results) {
        if (err) throw err;
        res.send('Update successfull');
    });
})

app.get("/hello", function (req, res) {
    res.send("Hello World");
})




var server = app.listen(8081, function () {
    var host = server.address().address
    var port = server.address().port
    console.log("Server is listening at http://%s:%s", host, port)
})
